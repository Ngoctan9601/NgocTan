<?php

class CartController {
    public function index(){
        echo __METHOD__;
    }

    public function store(){
        echo __METHOD__;
    }
}

;?>